package java4.baba.computer;

public interface CpuUsb {
    String getbrand();
    String getzhupin();
}
