package java4.baba.computer;

public interface EmsUsb {
    String gettype();

    Double getcapacity();
}
