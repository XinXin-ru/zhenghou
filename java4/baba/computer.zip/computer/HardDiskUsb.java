package java4.baba.computer;

public interface HardDiskUsb {
    Double getcapacity();
}
